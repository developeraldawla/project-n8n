import { Injectable, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { firstValueFrom, lastValueFrom, timer, throwError } from 'rxjs';
import { mergeMap, retryWhen, scan, delay, take } from 'rxjs/operators';
import { AxiosError } from 'axios';

@Injectable()
export class N8nProxyService {
    private readonly logger = new Logger(N8nProxyService.name);

    constructor(private readonly httpService: HttpService) { }

    async executeWebhook(url: string, payload: any, maxRetries = 3, timeoutMs = 30000) {
        return lastValueFrom(
            this.httpService.post(url, payload, {
                timeout: timeoutMs,
                responseType: 'arraybuffer', // Request as buffer to handle files
                validateStatus: null // Capture all statuses to handle in retry logic
            }).pipe(
                retryWhen(errors =>
                    errors.pipe(
                        mergeMap((error: AxiosError, index) => {
                            const attempt = index + 1;
                            const status = error.response?.status;

                            // Don't retry on 4xx Client Errors (except 429)
                            if (status && status >= 400 && status < 500 && status !== 429) {
                                return throwError(() => error);
                            }

                            if (attempt > maxRetries) {
                                return throwError(() => error);
                            }

                            const delayMs = Math.pow(2, attempt) * 1000;
                            this.logger.warn(`Webhook call failed. Retry attempt ${attempt}/${maxRetries} after ${delayMs}ms. Error: ${error.message}`);

                            return timer(delayMs);
                        })
                    )
                )
            )
        );
    }
}
