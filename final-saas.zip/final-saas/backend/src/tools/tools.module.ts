import { Module } from '@nestjs/common';
import { ToolsService } from './tools.service';
import { ToolsController } from './tools.controller';
import { AdminToolsController } from './admin-tools.controller';
import { ExecutionService } from './execution.service';
import { HttpModule } from '@nestjs/axios';
import { N8nProxyService } from './n8n-proxy.service';
import { PrismaModule } from '../prisma/prisma.module';
import { UsageModule } from '../usage/usage.module';
import { AuthModule } from '../auth/auth.module';
import { StorageModule } from '../storage/storage.module';
import { DataProcessingService } from './data-processing.service';

@Module({
    imports: [PrismaModule, HttpModule, UsageModule, AuthModule, StorageModule], // Added StorageModule
    controllers: [ToolsController],
    providers: [ToolsService, ExecutionService, N8nProxyService, DataProcessingService],
    exports: [ToolsService, ExecutionService]
})
export class ToolsModule { }
