import { Injectable, BadRequestException, NotFoundException, InternalServerErrorException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { ToolStatus } from '@prisma/client';
import Ajv from 'ajv';
import addFormats from 'ajv-formats';

@Injectable()
export class ToolsService {
    private ajv: Ajv;

    constructor(private prisma: PrismaService) {
        this.ajv = new Ajv({ allErrors: true });
        addFormats(this.ajv);
    }

    async createTool(data: any) {
        // Validate input schema structure
        this.validateJsonSchema(data.inputSchema);

        return this.prisma.tool.create({
            data: {
                name: data.name,
                slug: data.slug,
                category: data.category,
                description: data.description, // Added description
                versions: {
                    create: {
                        versionNumber: 1,
                        inputSchema: data.inputSchema,
                        outputSchema: data.outputSchema,
                        webhookUrl: data.webhookUrl,
                        isPublished: false // Draft by default
                    }
                }
            },
            include: { versions: true }
        });
    }

    async updateTool(id: string, data: any) {
        const tool = await this.prisma.tool.findUnique({ where: { id }, include: { versions: { orderBy: { versionNumber: 'desc' }, take: 1 } } });
        if (!tool) throw new NotFoundException('Tool not found');

        const latestVersion = tool.versions[0];
        const nextVersionNumber = latestVersion ? latestVersion.versionNumber + 1 : 1;

        // Create a new version
        if (data.inputSchema) this.validateJsonSchema(data.inputSchema);

        return this.prisma.$transaction(async (tx) => {
            // Update basic info
            await tx.tool.update({
                where: { id },
                data: {
                    name: data.name,
                    slug: data.slug,
                    category: data.category,
                    description: data.description,
                }
            });

            // Create new version
            return tx.toolVersion.create({
                data: {
                    toolId: id,
                    versionNumber: nextVersionNumber,
                    inputSchema: data.inputSchema || latestVersion.inputSchema,
                    outputSchema: data.outputSchema || latestVersion.outputSchema,
                    webhookUrl: data.webhookUrl || latestVersion.webhookUrl,
                    isPublished: false
                }
            });
        });
    }

    async publishVersion(toolId: string, versionNumber: number) {
        return this.prisma.$transaction(async (tx) => {
            const version = await tx.toolVersion.findUnique({
                where: { toolId_versionNumber: { toolId, versionNumber } }
            });
            if (!version) throw new NotFoundException('Version not found');

            // Update Tool currentVersion pointer
            await tx.tool.update({
                where: { id: toolId },
                data: {
                    currentVersion: versionNumber,
                    status: ToolStatus.ACTIVE
                }
            });

            // Mark version as published
            return tx.toolVersion.update({
                where: { id: version.id },
                data: { isPublished: true }
            });
        });
    }

    async findAll() {
        return this.prisma.tool.findMany({
            include: {
                versions: {
                    where: { isPublished: true },
                    orderBy: { versionNumber: 'desc' },
                    take: 1
                }
            }
        });
    }

    async findOne(id: string) {
        return this.prisma.tool.findUnique({
            where: { id },
            include: { versions: { orderBy: { versionNumber: 'desc' } } }
        });
    }

    // Helper: Validate that a user-provided JSON schema is actually a valid JSON schema
    private validateJsonSchema(schema: any) {
        try {
            const validate = this.ajv.compile(schema);
            return true;
        } catch (e: any) {
            throw new BadRequestException(`Invalid JSON Schema: ${e.message}`);
        }
    }

    // Helper: Validate USER INPUT against the Tool's Schema
    validateInput(schema: any, input: any) {
        try {
            const validate = this.ajv.compile(schema);
            const valid = validate(input);
            if (!valid) {
                throw new BadRequestException(`Input validation failed: ${this.ajv.errorsText(validate.errors)}`);
            }
            return true;
        } catch (e: any) {
            if (e instanceof BadRequestException) throw e;
            throw new InternalServerErrorException(`Schema validation error: ${e.message}`);
        }
    }
}
