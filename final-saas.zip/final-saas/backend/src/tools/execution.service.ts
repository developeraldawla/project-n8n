import { Injectable, HttpException, HttpStatus } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { firstValueFrom } from 'rxjs';
import { PrismaService } from '../prisma/prisma.service';
import { ToolsService } from './tools.service';
import { UsageService } from '../usage/usage.service';
import { N8nProxyService } from './n8n-proxy.service';
import { DataProcessingService } from './data-processing.service';

@Injectable()
export class ExecutionService {
    constructor(
        private prisma: PrismaService,
        private n8nProxyService: N8nProxyService,
        private toolsService: ToolsService,
        private usageService: UsageService,
        private dataProcessingService: DataProcessingService
    ) { }

    async executeTool(userId: string, toolId: string, input: any) {
        // 1. Fetch Tool & Version
        const tool = await this.prisma.tool.findUnique({
            where: { id: toolId },
            include: {
                versions: { where: { isPublished: true }, orderBy: { versionNumber: 'desc' }, take: 1 }
            }
        });

        if (!tool || tool.versions.length === 0) {
            throw new HttpException('Tool not available', HttpStatus.NOT_FOUND);
        }
        const version = tool.versions[0];

        // 2. Validate Input Schema
        this.toolsService.validateInput(version.inputSchema, input);

        // 3. Validate Usage Limits
        await this.usageService.checkLimit(userId, toolId);

        // 4. Call n8n Webhook via Proxy
        const webhookUrl = version.webhookUrl;
        try {
            const startTime = Date.now();

            // Execute with retries
            const response = await this.n8nProxyService.executeWebhook(webhookUrl, {
                user_id: userId,
                tool_id: toolId,
                input: input
            });

            const duration = Date.now() - startTime;

            // 5. Output Mapping & Validation
            const headers = response.headers;
            const contentType = headers['content-type'] || '';

            let resultData: any;

            if (this.isBinary(contentType)) {
                // Determine extension from content-type or header
                const extension = this.getExtension(contentType);
                resultData = await this.dataProcessingService.processFileResponse(response.data as Buffer, contentType, extension);
            } else {
                // Assume JSON or Text
                const data = response.data;
                // If it's a buffer but actually JSON (because we forced arraybuffer), parse it
                if (Buffer.isBuffer(data)) {
                    try {
                        resultData = JSON.parse(data.toString('utf-8'));
                    } catch (e) {
                        // Fallback to treating as text or raw file if not JSON
                        const extension = 'txt';
                        resultData = await this.dataProcessingService.processFileResponse(data, 'text/plain', extension);
                    }
                } else {
                    resultData = data;
                }
            }

            if (version.outputSchema) {
                // We could validate here using this.toolsService.validateSchema(version.outputSchema, resultData)
            }

            // 6. Log Execution
            await this.prisma.executionLog.create({
                data: {
                    userId,
                    toolId,
                    toolVersionId: version.id,
                    status: 'SUCCESS',
                    durationMs: duration,
                    inputSnapshot: input,
                    outputSnapshot: resultData
                }
            });

            // 7. Track Usage
            await this.usageService.incrementUsage(userId, toolId, 'SUCCESS');

            return resultData;
        } catch (error) {
            // Log Failure
            await this.prisma.executionLog.create({
                data: {
                    userId,
                    toolId,
                    toolVersionId: version.id,
                    status: 'FAILED',
                    durationMs: 0,
                    inputSnapshot: input,
                    errorDetails: error.message
                }
            });

            // Track Usage (Failed attempts might count depending on policy, usually we track them)
            await this.usageService.incrementUsage(userId, toolId, 'FAILED');

            throw new HttpException('Tool execution failed', HttpStatus.BAD_GATEWAY);
        }
    }

    private isBinary(contentType: string): boolean {
        return contentType.includes('spreadsheet') ||
            contentType.includes('excel') ||
            contentType.includes('csv') ||
            contentType.includes('image') ||
            contentType.includes('pdf') ||
            contentType.includes('zip') ||
            contentType.includes('octet-stream');
    }

    private getExtension(contentType: string): string {
        if (contentType.includes('csv')) return 'csv';
        if (contentType.includes('spreadsheet') || contentType.includes('excel')) return 'xlsx';
        if (contentType.includes('json')) return 'json';
        if (contentType.includes('png')) return 'png';
        if (contentType.includes('jpeg')) return 'jpg';
        if (contentType.includes('pdf')) return 'pdf';
        return 'bin';
    }
}
