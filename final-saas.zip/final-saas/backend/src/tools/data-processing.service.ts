import { Injectable, Logger } from '@nestjs/common';
import * as XLSX from 'xlsx';
import * as Papa from 'papaparse';
import { StorageService } from '../storage/storage.service';

@Injectable()
export class DataProcessingService {
    private readonly logger = new Logger(DataProcessingService.name);

    constructor(private storageService: StorageService) { }

    /**
     * Processing pipeline:
     * 1. Upload raw file to S3.
     * 2. If spreadsheet/CSV, parse content to JSON.
     * 3. Analyze data types for frontend charting.
     */
    async processFileResponse(buffer: Buffer, mimeType: string, extension: string): Promise<any> {
        this.logger.log(`Processing file: ${mimeType}, size: ${buffer.length}`);

        // 1. Upload to S3
        const uploadResult = await this.storageService.uploadBuffer(buffer, mimeType, extension);

        // 2. Parse if supported
        let parsedData = null;
        let chartData = null;

        if (this.isSpreadsheet(mimeType, extension)) {
            try {
                parsedData = this.parseSpreadsheet(buffer, extension);
                chartData = this.analyzeForCharts(parsedData);
            } catch (error) {
                this.logger.error(`Failed to parse spreadsheet: ${error.message}`);
                // We don't fail the whole request, just return the file without parsed data
            }
        }

        return {
            type: 'FILE_OUTPUT',
            file: {
                key: uploadResult.key,
                url: uploadResult.url,
                mimeType,
                extension,
                size: buffer.length
            },
            data: parsedData,
            visualization: chartData
        };
    }

    private isSpreadsheet(mime: string, ext: string): boolean {
        return [
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'application/vnd.ms-excel',
            'text/csv'
        ].includes(mime) || ['xlsx', 'xls', 'csv'].includes(ext);
    }

    private parseSpreadsheet(buffer: Buffer, ext: string): any[] {
        if (ext === 'csv') {
            const content = buffer.toString('utf-8');
            const result = Papa.parse(content, { header: true, dynamicTyping: true, skipEmptyLines: true });
            return result.data;
        }

        const workbook = XLSX.read(buffer, { type: 'buffer' });
        const sheetName = workbook.SheetNames[0];
        return XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);
    }

    private analyzeForCharts(data: any[]): any {
        if (!data || data.length === 0) return null;

        const keys = Object.keys(data[0]);
        // Simple heuristic: 
        // 1. Identify "Categorical" (Strings) vs "Numerical" (Numbers)
        // 2. If we have 1 String + 1 Number -> Bar/Pie Chart candidate.
        // 3. If we have Date + Number -> Line Chart candidate.

        const schema = keys.map(key => {
            const sample = data[0][key];
            const type = typeof sample;
            return { key, type };
        });

        const numericKeys = schema.filter(f => f.type === 'number').map(f => f.key);
        const stringKeys = schema.filter(f => f.type === 'string').map(f => f.key);

        if (numericKeys.length > 0 && stringKeys.length > 0) {
            return {
                suggestedChart: 'bar', // Default to bar
                xAxis: stringKeys[0], // Pick first string as label
                yAxis: numericKeys, // Pick all numbers as data lines
                title: `Analysis by ${stringKeys[0]}`
            };
        }

        return null;
    }
}
