import { Controller, Get, Post, Put, Body, Param, ParseIntPipe, UseGuards } from '@nestjs/common';
import { ToolsService } from './tools.service';

@Controller('admin/tools')
export class AdminToolsController {
    constructor(private readonly toolsService: ToolsService) { }

    @Post()
    create(@Body() createToolDto: any) {
        return this.toolsService.createTool(createToolDto);
    }

    @Put(':id')
    update(@Param('id') id: string, @Body() updateToolDto: any) {
        return this.toolsService.updateTool(id, updateToolDto);
    }

    @Post(':id/publish/:version')
    publish(@Param('id') id: string, @Param('version', ParseIntPipe) version: number) {
        return this.toolsService.publishVersion(id, version);
    }
}
