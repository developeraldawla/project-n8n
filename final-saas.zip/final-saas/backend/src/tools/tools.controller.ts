import { Controller, Get, Post, Body, UseGuards, Param, Request } from '@nestjs/common';
import { ToolsService } from './tools.service';
import { ExecutionService } from './execution.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';

@Controller('tools')
export class ToolsController {
    constructor(
        private readonly toolsService: ToolsService,
        private readonly executionService: ExecutionService
    ) { }

    @Get()
    findAll() {
        return this.toolsService.findAll();
    }

    @Get(':id')
    findOne(@Param('id') id: string) {
        return this.toolsService.findOne(id);
    }

    @Post(':id/execute')
    @UseGuards(JwtAuthGuard)
    execute(@Param('id') id: string, @Body() body: any, @Request() req: any) {
        return this.executionService.executeTool(req.user.userId, id, body.input);
    }
}
