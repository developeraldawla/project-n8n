import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import Stripe from 'stripe';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class StripeService {
    private stripe: Stripe;
    private readonly logger = new Logger(StripeService.name);

    constructor(
        private configService: ConfigService,
        private prisma: PrismaService
    ) {
        const apiKey = this.configService.get<string>('STRIPE_SECRET_KEY');
        if (!apiKey) {
            this.logger.error('STRIPE_SECRET_KEY is not defined');
            // Prevent crash for now if key is missing, but log error
            this.stripe = new Stripe('dummy', { apiVersion: '2024-12-18.acacia' as any });
        } else {
            this.stripe = new Stripe(apiKey, { apiVersion: '2024-12-18.acacia' as any });
        }
    }

    async createCheckoutSession(userId: string, priceId: string) {
        const user = await this.prisma.user.findUnique({ where: { id: userId } });
        if (!user) throw new Error('User not found');

        let customerId = user.stripeCustomerId;
        if (!customerId) {
            const customer = await this.stripe.customers.create({ email: user.email });
            customerId = customer.id;
            await this.prisma.user.update({
                where: { id: userId },
                data: { stripeCustomerId: customerId }
            });
        }

        return this.stripe.checkout.sessions.create({
            customer: customerId!,
            mode: 'subscription',
            payment_method_types: ['card'],
            line_items: [{ price: priceId, quantity: 1 }],
            subscription_data: {
                trial_period_days: 3, // 3-Day Free Trial
            },
            success_url: `${this.configService.get('FRONTEND_URL')}/dashboard?success=true`,
            cancel_url: `${this.configService.get('FRONTEND_URL')}/billing?canceled=true`,
            metadata: { userId }
        });
    }

    async handleWebhook(signature: string, payload: Buffer) {
        const webhookSecret = this.configService.get<string>('STRIPE_WEBHOOK_SECRET');
        let event: Stripe.Event;

        try {
            event = this.stripe.webhooks.constructEvent(payload, signature, webhookSecret!);
        } catch (err) {
            this.logger.error(`Webhook signature verification failed: ${err.message}`);
            throw new Error('Webhook signature verification failed');
        }

        switch (event.type) {
            case 'checkout.session.completed':
            case 'customer.subscription.updated':
            case 'customer.subscription.deleted':
                await this.syncSubscription(event.data.object as any);
                break;
            default:
                this.logger.log(`Unhandled event type ${event.type}`);
        }
    }

    private async syncSubscription(data: any) {
        let stripeSubscriptionId = data.id;
        let customerId = data.customer;
        let status = data.status;

        // If event is checkout.session, we might need to fetch the subscription
        if (data.object === 'checkout.session') {
            stripeSubscriptionId = data.subscription;
            if (typeof stripeSubscriptionId !== 'string') {
                // Retrieve if expanded object, though usually ID in webhooks
                return;
            }
        }

        // Fetch fresh subscription details from Stripe to be sure
        const subscription: any = await this.stripe.subscriptions.retrieve(stripeSubscriptionId);
        if (!subscription) return; // Guard clause

        customerId = subscription.customer as string;
        status = subscription.status;

        const user = await this.prisma.user.findFirst({ where: { stripeCustomerId: customerId } });
        if (!user) {
            this.logger.warn(`User not found for Stripe Customer ${customerId}`);
            return;
        }

        // Map Stripe status to Enum
        let dbStatus = 'ACTIVE';
        if (status === 'trialing') dbStatus = 'TRIALING';
        if (status === 'active') dbStatus = 'ACTIVE';
        if (status === 'past_due' || status === 'unpaid') dbStatus = 'PAST_DUE';
        if (status === 'canceled' || status === 'incomplete_expired') dbStatus = 'CANCELED';

        // Update DB
        const subscriptionData = {
            stripeSubscriptionId: subscription.id,
            status: dbStatus as any,
            currentPeriodStart: new Date(subscription.current_period_start * 1000),
            currentPeriodEnd: new Date(subscription.current_period_end * 1000),
            trialEnd: subscription.trial_end ? new Date(subscription.trial_end * 1000) : null
        };

        await this.prisma.subscription.upsert({
            where: { userId: user.id },
            update: subscriptionData,
            create: {
                userId: user.id,
                ...subscriptionData
            }
        });

        this.logger.log(`Synced subscription for user ${user.email} -> ${dbStatus}`);
    }
}
