import { Controller, Post, Body, Headers, BadRequestException, UseGuards, Request, RawBodyRequest, Req } from '@nestjs/common';
import { StripeService } from './stripe.service';
import { PaymentService } from '../payments/payment.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { Request as ExpressRequest } from 'express';

@Controller('subscription')
export class SubscriptionController {
    constructor(
        private stripeService: StripeService,
        private paymentService: PaymentService,
    ) { }

    @UseGuards(JwtAuthGuard)
    @Post('checkout')
    async createCheckout(@Request() req: any, @Body() body: { priceId: string }) {
        if (!body.priceId) throw new BadRequestException('Price ID required');
        // Use PaymentService to keep gateway-agnostic behavior
        return this.paymentService.createCheckout(req.user.userId, body.priceId);
    }

    @Post('webhook')
    async handleWebhook(@Headers('stripe-signature') signature: string, @Req() req: any) {
        if (!signature) throw new BadRequestException('Missing Signature');
        // NestJS with raw body enabled
        if (!req.rawBody) throw new BadRequestException('Raw body not available');

        return this.stripeService.handleWebhook(signature, req.rawBody);
    }
}
