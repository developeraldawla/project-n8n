import { Injectable, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class PlansService {
    constructor(private prisma: PrismaService) { }

    async createPlan(data: any) {
        return this.prisma.plan.create({
            data: {
                name: data.name,
                slug: data.slug,
                priceMonthly: data.priceMonthly,
                priceYearly: data.priceYearly,
                features: data.features || {},
                limits: data.limits || {},
                isTrialEnabled: data.isTrialEnabled,
                trialDays: data.trialDays
            }
        });
    }

    async findAll() {
        return this.prisma.plan.findMany({
            where: { isActive: true }
        });
    }

    async updatePlan(id: string, data: any) {
        return this.prisma.plan.update({
            where: { id },
            data
        });
    }
}
