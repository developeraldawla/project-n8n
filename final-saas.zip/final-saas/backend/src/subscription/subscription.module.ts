import { Module } from '@nestjs/common';
import { PlansService } from './plans.service';
import { PlansController } from './plans.controller';
import { StripeService } from './stripe.service';
import { SubscriptionController } from './subscription.controller';
import { FeatureFlagService } from './feature-flag.service';
import { PaymentService } from '../payments/payment.service';
import { StripeAdapter } from '../payments/stripe.adapter';

@Module({
    controllers: [PlansController, SubscriptionController],
    providers: [
        PlansService,
        StripeService,
        FeatureFlagService,
        PaymentService,
        { provide: 'IPaymentGateway', useClass: StripeAdapter },
    ],
    exports: [PlansService, StripeService, FeatureFlagService, PaymentService],
})
export class SubscriptionModule { }
