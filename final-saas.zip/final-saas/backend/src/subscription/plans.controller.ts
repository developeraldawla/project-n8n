import { Controller, Get, Post, Body, Put, Param, UseGuards } from '@nestjs/common';
import { PlansService } from './plans.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { RolesGuard } from '../auth/roles.guard';
import { Roles } from '../auth/roles.decorator';

@Controller('admin/plans')
@UseGuards(JwtAuthGuard, RolesGuard)
@Roles('ADMIN', 'SUPER_ADMIN')
export class PlansController {
    constructor(private readonly plansService: PlansService) { }

    @Post()
    create(@Body() createPlanDto: any) {
        return this.plansService.createPlan(createPlanDto);
    }

    @Get()
    findAll() {
        return this.plansService.findAll();
    }

    @Put(':id')
    update(@Param('id') id: string, @Body() updatePlanDto: any) {
        return this.plansService.updatePlan(id, updatePlanDto);
    }
}
