import { Controller, Get, Request, UseGuards } from '@nestjs/common';
import { UsageService } from './usage.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';

@Controller('stats')
export class UsageController {
    constructor(private usageService: UsageService) { }

    @UseGuards(JwtAuthGuard)
    @Get('mine')
    async getMyStats(@Request() req: any) {
        return this.usageService.getUserStats(req.user.userId);
    }
}
