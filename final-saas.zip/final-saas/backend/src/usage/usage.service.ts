import { Injectable, HttpException, HttpStatus } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { ExecutionStatus } from '@prisma/client';

@Injectable()
export class UsageService {
    constructor(private prisma: PrismaService) { }

    async checkLimit(userId: string, toolId: string): Promise<boolean> {
        // 1. Fetch User, Plan, and Subscription
        const user = await this.prisma.user.findUnique({
            where: { id: userId },
            include: {
                plan: true,
                subscription: true
            }
        });

        if (!user || !user.plan) {
            throw new HttpException('User has no active plan', HttpStatus.FORBIDDEN);
        }

        // Check Subscription Status
        if (user.subscription &&
            !['ACTIVE', 'TRIALING'].includes(user.subscription.status)) {
            throw new HttpException('Subscription is not active', HttpStatus.PAYMENT_REQUIRED);
        }

        // 2. Fetch Tool Access Rules
        const toolAccess = await this.prisma.toolAccess.findUnique({
            where: {
                toolId_planId: {
                    toolId: toolId,
                    planId: user.plan.id
                }
            }
        });

        if (toolAccess && toolAccess.isHidden) {
            throw new HttpException('This tool is not included in your plan', HttpStatus.FORBIDDEN);
        }

        // 3. Determine Limits
        // Default to safe defaults if not defined
        const planLimits = user.plan.limits as any || {};
        const dailyLimit = planLimits.tools_daily || 0; // 0 means blocked, use -1 for unlimited? or huge number

        // 4. Calculate Usage for Today
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        // Sum up all usage for today across all tools for global limit
        const usageAggregates = await this.prisma.usageAggregate.groupBy({
            by: ['userId'],
            where: {
                userId: userId,
                date: today
            },
            _sum: {
                count: true
            }
        });

        const currentDailyUsage = usageAggregates[0]?._sum.count || 0;

        if (currentDailyUsage >= dailyLimit) {
            throw new HttpException(`Daily execution limit reached (${dailyLimit})`, HttpStatus.TOO_MANY_REQUESTS);
        }

        return true;
    }

    async incrementUsage(userId: string, toolId: string, status: ExecutionStatus) {
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        await this.prisma.usageAggregate.upsert({
            where: {
                userId_toolId_date: {
                    userId,
                    toolId,
                    date: today
                }
            },
            update: {
                count: { increment: 1 },
                successCount: status === 'SUCCESS' ? { increment: 1 } : undefined,
                failureCount: status !== 'SUCCESS' ? { increment: 1 } : undefined
            },
            create: {
                userId,
                toolId,
                date: today,
                count: 1,
                successCount: status === 'SUCCESS' ? 1 : 0,
                failureCount: status !== 'SUCCESS' ? 1 : 0
            }
        });
    }

    async getUserStats(userId: string) {
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        // 1. Get Plan Limits
        const user = await this.prisma.user.findUnique({
            where: { id: userId },
            include: { plan: true }
        });
        const limits = user?.plan?.limits as any || {};
        const dailyLimit = limits.tools_daily || 0;

        // 2. Aggregate Today's Usage
        const todayUsage = await this.prisma.usageAggregate.aggregate({
            _sum: {
                count: true,
                successCount: true,
                failureCount: true
            },
            where: {
                userId,
                date: today
            }
        });

        const totalExecutions = todayUsage._sum.count || 0;
        const totalSuccess = todayUsage._sum.successCount || 0;
        const totalFailed = todayUsage._sum.failureCount || 0;

        return {
            planName: user?.plan?.name || 'Free',
            dailyLimit,
            today: {
                total: totalExecutions,
                success: totalSuccess,
                failed: totalFailed,
                remaining: Math.max(0, dailyLimit - totalExecutions)
            }
        };
    }
}
